
public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("안녕하세여!");
//		System.out.println('헬로 키티 월드');	->문자열은 ''로 하지 말고 ""로 해야한다.
		System.out.println("헬로 키티 월드");
	}
}
