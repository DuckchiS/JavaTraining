package com.peisia.c.KioskV3.product;

import com.peisia.c.KioskV3.Product;

public class Drink extends Product{
	public Drink(String name, int price, int type) {
		super(name, price, type);
	}
}
