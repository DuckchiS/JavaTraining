package com.peisia.c.KioskV3;

import java.util.ArrayList;
import java.util.Scanner;

import com.peisia.c.kioskV2.ProcMenuDessert;
import com.peisia.c.kioskV2.Product;

public class Kiosk {
	void run(){
		Display.title();
		KioskObj.productLoad();	//상품로드
		loop_a:
			while(true) {
				System.out.println("어떤 메뉴를 주문하시겠습니까?");
				System.out.println("1번 음료 2번 디저트 3번 텀블러/피규어 x는 프로그램 종료입니다.");
				KioskObj.cmd = KioskObj.sc.next();
				switch (KioskObj.cmd) {
				case "1":
					ProcMenuDrink.run();
					break;
					
				case "2":
					ProcMenuDesserts.run();
					break;
					
				case "3":
					ProcMenuTumbler.run();
					break;
					
				case "x":
					int count = KioskObj.basket.size();
					System.out.println("장바구니에 담긴 상품 갯수: " + count);
					int sum = 0;
					for(Order o : KioskObj.basket) {
						sum = sum + o.selectProduct.price;
					}
					System.out.println("계산하실 금액은 " + sum + "원 입니다.");
					System.out.println("=========================");
					for(Order o : KioskObj.basket) { 		////	산거 리스팅	////
						System.out.println(o.selectProduct.name);
					}
					System.out.println("=========================");
					System.out.println("프로그램을 종료합니다.");
					break loop_a;
					
				default:
					System.out.println("옵션에 없습니다. 다시 해주세요.");
					break;
				}
			}
	}
}
