package com.peisia.c.KioskV3;

public class Main {
	public static void main(String[] args) {
		Kiosk kiosk = new Kiosk();
		kiosk.run();
		
		System.out.println(Display.DOT);
	}
}
