package com.peisia.c.KioskV3.product;

import com.peisia.c.KioskV3.Product;

public class Dessert extends Product{
	public Dessert(String xx, int yy) {
		super(xx, yy);
	}
}
