package com.peisia.c.KioskV3.product;

import com.peisia.c.KioskV3.Product;

public class Dessert extends Product{
	public Dessert(String name, int price, int type) {
		super(name, price, type);
	}
}
