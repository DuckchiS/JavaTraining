package com.peisia.c.KioskV3.product;

import com.peisia.c.KioskV3.Product;

public class Products extends Product{
	public Products(String name, int price, int type) {
		super(name, price, type);
	}
}
