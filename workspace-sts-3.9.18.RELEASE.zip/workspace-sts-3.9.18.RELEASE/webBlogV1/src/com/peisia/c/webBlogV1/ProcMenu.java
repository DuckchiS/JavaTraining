package com.peisia.c.webBlogV1;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.webBlog.display.Display;

public class ProcMenu {
	public static void run() {
		Display.menuMain();
		loop:while(true) {
			String cmd = Ci.r("[명령]");
			switch(cmd) {
				case "1":
					//list
					ProcMenuList.run();
					break;
				case "2":
					//read
					ProcMenuRead.run();
					break;
				case "3":
					//write
					ProcMenuWrite.run();
					break;
				case "4":
					//del
					ProcMenuDel.run();
					break;
				case "5":
					//update
					ProcMenuUpdate.run();
					break;
				case "x":
					Cw.wn("블로그를 종료합니다.");
					break loop;
				default:
					Cw.wn("옵션에 없습니다. 다시 입력하세요.");
					break;
			}
		}
	}
}
