package com.pay.c.test;

public class JavaTest {
	public static void main(String[] args) {

		
		Dog duri = new Dog();
		
		duri.age = 5;
		duri.name = "duri";
		duri.info();
		
	}
}
