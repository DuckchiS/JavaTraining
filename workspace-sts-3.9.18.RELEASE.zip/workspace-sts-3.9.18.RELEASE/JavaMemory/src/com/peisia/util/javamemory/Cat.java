package com.peisia.util.javamemory;

public class Cat {
	int age;
	
}
