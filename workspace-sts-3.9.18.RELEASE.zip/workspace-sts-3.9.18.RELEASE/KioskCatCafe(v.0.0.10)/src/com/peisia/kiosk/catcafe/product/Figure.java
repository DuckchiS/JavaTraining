package com.peisia.kiosk.catcafe.product;

public class Figure extends Product{

	public Figure(String xx, int yy) {
		super(xx, yy);
	}

}
