package com.peisia.kiosk.catcafe.product;

public class Food extends Product{
	public Food(String xx, int yy) {
		super(xx, yy);
	}

	public String expiryDate;
}
