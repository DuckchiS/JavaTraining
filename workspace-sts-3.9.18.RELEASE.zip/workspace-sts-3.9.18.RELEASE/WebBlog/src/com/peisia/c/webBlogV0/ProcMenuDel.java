package com.peisia.c.webBlogV0;

import com.peisia.c.util.Cw;

public class ProcMenuDel {
	public static void run() {
		Cw.wn("게시글 삭제 입니다.");
	}
}
