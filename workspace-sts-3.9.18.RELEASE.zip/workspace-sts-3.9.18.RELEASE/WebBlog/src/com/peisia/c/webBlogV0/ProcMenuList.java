package com.peisia.c.webBlogV0;

import com.peisia.c.util.Cw;

public class ProcMenuList {
	public static void run() {
		Cw.wn("게시글 목록 입니다.");
	}
}
