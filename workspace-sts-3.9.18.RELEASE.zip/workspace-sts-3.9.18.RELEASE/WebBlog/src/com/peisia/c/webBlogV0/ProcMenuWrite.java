package com.peisia.c.webBlogV0;

import com.peisia.c.util.Cw;

public class ProcMenuWrite {
	public static void run() {
		Cw.wn("게시글 쓰기 입니다.");
	}
}
