package com.peisia.c.webBlogV0;

import com.peisia.c.util.Cw;

public class ProcMenuRead {
	public static void run() {
		Cw.wn("게시글 읽기 입니다.");
	}
}
