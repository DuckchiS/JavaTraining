package com.pay.rpg.c.java;

public class Main {
	public static void main(String[] args) {
		Charcter emp = new Charcter("emp", 100, 10, "witch");
		
		emp.info();
	}
}
