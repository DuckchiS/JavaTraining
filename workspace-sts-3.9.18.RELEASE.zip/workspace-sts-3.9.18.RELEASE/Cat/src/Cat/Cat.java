package Cat;

public class Cat {
	int age;
	String name;
	
	void info() {
		String s = "고양이 이름은 " + name + "이고 나이는 " + age + " 살 이예용";
		System.out.println(s);
	}
}
