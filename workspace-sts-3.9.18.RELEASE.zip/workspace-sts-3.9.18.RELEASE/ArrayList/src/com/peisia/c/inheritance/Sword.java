package com.peisia.c.inheritance;

public class Sword extends Item{
	int attack;

	//alt + shift + s
	
	
	
	void slash() {
		System.out.println(name+"으로 "+attack+" 데미지로 공격함"+weight);
	}

	
	
	public Sword(String name,int grade,int attack,int weight,int life) {
		super(name,grade,weight,life); //맨 처음에 온다 이거는 부모 클래스를 나타내는거다.
		this.attack = attack;
	}

}
