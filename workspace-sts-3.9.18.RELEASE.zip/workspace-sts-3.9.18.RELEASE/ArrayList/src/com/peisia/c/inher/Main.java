package com.peisia.c.inher;

public class Main {
	public static void main(String[] args) {
		Character c = new Character();
	}
}
