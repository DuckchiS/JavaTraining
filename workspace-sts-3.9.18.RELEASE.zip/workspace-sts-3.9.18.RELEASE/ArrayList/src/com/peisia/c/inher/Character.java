package com.peisia.c.inher;

public class Character extends GameObj{
	int hp;
	Character() {
//		super();
//		super()가 없어도 기본으로 생성이 되어 있음
		System.out.println("자식 객체가 생성됬음");
	}
}
