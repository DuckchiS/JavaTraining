package com.peisia.util.inheritance;

public class Item extends GameObj{
//	String name;
	
	int weight;
	int 수명;
	
}
