package com.peisia.util.inheritance;

public class Sword extends Item{
	int attack;
	void Cinfo() {
		System.out.println("공격력: " + attack);
	}

}
