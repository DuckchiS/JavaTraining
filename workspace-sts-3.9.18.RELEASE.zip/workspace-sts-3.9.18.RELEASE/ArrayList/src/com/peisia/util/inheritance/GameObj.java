package com.peisia.util.inheritance;

public class GameObj {
	String name;
	
	void info() {
		System.out.println("이름:"+name);
	}
}
