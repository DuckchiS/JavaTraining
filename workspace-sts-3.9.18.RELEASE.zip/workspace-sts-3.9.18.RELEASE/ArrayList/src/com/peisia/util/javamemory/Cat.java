package com.peisia.util.javamemory;

public class Cat {
	String name;
	int age;
}
