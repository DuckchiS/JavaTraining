package com.peisia.util.javamemory;

public class Hospital {
	void hotel(Cat c) {
		System.out.println(c.name + "가 맡겨졌습니다.");
	}
}
