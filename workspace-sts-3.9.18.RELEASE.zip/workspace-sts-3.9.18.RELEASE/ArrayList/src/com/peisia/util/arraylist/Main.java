package com.peisia.util.arraylist;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		ArrayList<String> xx = new ArrayList<String>();
		xx.add("cat");
		xx.add("dog");
		xx.set(1, "puppy");
		xx.add("nuguri");
		xx.add("panda");
		xx.remove(3);
//		xx.clear();
		System.out.println("몇 개?" + xx.size());
		for(int i=0;i<xx.size();i=i+1) {
			System.out.println(xx.get(i));
		}
		boolean hasCat = xx.contains("cat");
		if(hasCat == true) {
			System.out.println("cat 있음");
		}else {
			System.out.println("cat 없음");
		}
		
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ab.add(1);
		ab.add(18);
		ab.add(3);
		ab.set(2, 28);
		ab.add(24);
		ab.remove(3);
//		ab.clear();
		System.out.println("몇 개?" + ab.size());
		for(int j = 0; j < ab.size(); j++) {
			System.out.println(ab.get(j));	
		}
		boolean nit28 = ab.contains(28);
		if(nit28 == true) {
			System.out.println("28이 있음");
		}else {
			System.out.println("28이 없음");
		}
	}
}
