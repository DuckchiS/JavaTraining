package com.pay.java.lotto;

public class Main {
	public static void main(String[] args) {
//		Lotto l = new Lotto();
//		l.random();
		
//		LottoV2 lotto = new LottoV2();
//		lotto.random2();
		
		LottoV3 lotto3 = new LottoV3();
		lotto3.random3();
		
		
	}
}

