package Rpc;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Rps rps = new Rps();
		rps.run();
	}
	
}


